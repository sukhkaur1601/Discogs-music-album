# music-app
Rythmic
-Rythmic Music App is a one page application.

-used Discogs rest APIs to search Artist.

-create the playlist from the searched artist albums and display the playlist

-created Restful APIs to interact with the Database

Languages And Technologies Used
-Node.js

-React.js

-Postgres

-HTML5

-CSS3

-JavaScript
