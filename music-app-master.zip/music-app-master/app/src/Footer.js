import React from 'react';
import './Footer.css';

class Footer extends React.Component{
    render(){
        return <footer><h3>&copy; Amandeep Sharma, Gursharan Kaur, Sukhwinder Kaur</h3></footer>;
    }
}

export default Footer;